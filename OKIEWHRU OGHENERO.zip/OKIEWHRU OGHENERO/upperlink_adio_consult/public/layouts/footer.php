<div class="clearfix"></div>
<div class="footer">
  <p>&copy; <?php echo date("Y"); ?> Adio Consultancy Group, All Right Reserved.</p>
</div>
</div>
</body>
</html>