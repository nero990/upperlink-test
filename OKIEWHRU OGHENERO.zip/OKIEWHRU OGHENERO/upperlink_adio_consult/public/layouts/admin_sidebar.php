<ul class="nav">
  <li><a href="applicant_list.php">Applicant List</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>